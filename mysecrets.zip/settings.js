module.exports = {
  emailSettings: {
    subject: 'Testing My Todo Lists',
    // host: 'smtp-mail.outlook.com',
    // secureConnection: false,
    // tls: {
    //   ciphers: 'SSLv3'
    // },
    service: 'hotmail',
    auth: { user: 'youremail@hotmail.com', pass: 'passwordofyourhotemailaccount' }
  }
};